package DAO.IDAO;

import java.util.ArrayList;

import modelo.Usuario;

public interface IUsDAO {

	public ArrayList<Usuario> listar_us();
	
}
