package modelo;

import modelo.IModelo.IContacto;

public class ContactoImpl implements IContacto {

	//Muestra datos del contacto en consola.
	public void Ingreso_Contacto(Contacto cont) {
		// TODO Auto-generated method stub
		System.out.println(cont.toString());
	}

	
	
}
