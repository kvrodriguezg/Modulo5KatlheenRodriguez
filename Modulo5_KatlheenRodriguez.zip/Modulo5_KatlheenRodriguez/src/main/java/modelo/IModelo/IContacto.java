package modelo.IModelo;

import modelo.Contacto;

public interface IContacto {
	
	public void Ingreso_Contacto(Contacto cont);

}
